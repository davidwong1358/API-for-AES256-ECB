package com.example.aes256_ecb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aes256EcbApplicationTests {

	@Test
	void contextLoads() {
	}

}
